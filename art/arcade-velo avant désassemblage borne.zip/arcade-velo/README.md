# Micro Rider — studio visuel

Ouvrir `index.html` directement dans un navigateur. Aucun serveur ni installation nécessaires.

- `index.html` : dernière version du studio, 5 bornes et 7 univers indépendants, mode jeu grand écran, HUD et instruments animés, curseurs de démonstration.
- `assets/bornes/` : les 5 rendus de bornes utilisés.
- `assets/jeux/` : les 7 décors utilisés.
- `../archive/versions-de-travail/` : anciennes maquettes, versions intermédiaires et documentation de création. Leur structure est conservée pour permettre de les consulter.

Les scènes restent des images fixes. Les mesures sont simulées, sans liaison au home trainer.

## Assemblage modulaire

Le haut (avec les courbures), les montants courts/longs, la console et le pied sont assemblés séparément. Les montants longs répètent une portion de texture à échelle native ; ce sont des compositions SVG du rendu existant, pas de nouveaux rendus peints. Les raccords peuvent demander une retouche artistique. Le pied disparaît en mode jeu.

Cassette : animations dans les surfaces de verre et les logements LED existants. Steampunk : aiguilles superposées aux cadrans existants, sans panneau opaque. Années 90 : logement animé avec inclinaison en perspective. Les aiguilles peintes dans le rendu steampunk d’origine restent présentes ; une prochaine passe d’illustration pourra fournir des cadrans sans aiguilles pour une intégration finale.
